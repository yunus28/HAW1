import java.util.*;

/**
 * Eine Klasse mit mehreren Dienstleister-Methoden.
 * Die Ruempfe sind sinnvoll zu fuellen!
 * 
 * @author (Dein Name, Deine Matrikelnummer)
 */
class ServiceMixImpl implements ServiceMix
{
    public ServiceMixImpl()
    {
        // Diesen Konstruktor unbedingt stehen lassen!
    }

    public int anzahlDuplikate(List<String> woerter)
    {
        return 0;
    }

    public int anzahlAuftreten(char vonChar, String inString)
    {
        return 0;
    }

    public String worteVerbinden(List<String> worte)
    {
        return null;
    }

    public String[] konkateniere(String[] s1, String[] s2)
    {
        return null;
    }

    public String snakeCaseToCamelCase(String name)
    {
        return null;
    }

}
